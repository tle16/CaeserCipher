#include "cipher.h"

int main(int argc, char **argv) {
    FILE *origin;
    FILE *copy;
    int i, j;
    char temp[500];
    char holder[1024][1024];
    i = 0;

    if(argc == 1) { /*only ./ command entered*/
        while(temp[0] != '.') {
            fgets(temp, MAX_LENGTH, stdin);
            strcpy(holder[i], temp);
            i++;
        }
        for(j = 0; j < i; j++) {
            printf("%s", holder[j]);
        }
    }
    if(argc == 2) { /* ./ with a file that it going to be read and displayed in stdout*/
        origin = fopen(argv[1], "r");
        while(fgets(temp, MAX_LENGTH, origin) != NULL) {
            strcpy(holder[i], temp);
            i++;
        }
        for(j = 0; j < i; j++) {
            printf("%s", holder[j]);
        }
        printf("\n");
        fclose(origin);
    }
    if(argc == 3) { /*copy first specified text file contents to the second*/
        origin = fopen(argv[1], "r");
        copy = fopen(argv[2], "w");
        while(fgets(temp, MAX_LENGTH, origin) != NULL) {
            fprintf(copy, temp);
        }
        fclose(origin);
        fclose(copy);
    }

    return 0;
}