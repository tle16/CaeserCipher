#include "cipher.h"

int main(int argc, char *argv[]) {
    FILE *dj;
    FILE *Sahibjeet;
    char *Syad = NULL;
    char file;
    char **array = NULL;
    int i, j, k, length, F, O;
    int shift;
    F = 0;
    O = 0;

    for(i = 0; i < argc; i++) { /*finds the location of the commands*/
        if((strcmp(argv[i], "-F") == 0) || (argv[i][0] == 'F')) {
            F = i;
        }
        if((strcmp(argv[i], "-O") == 0) || (argv[i][0] == 'O')) {
            O = i;
        }
    }

    for(i = 0; i < argc; i++) { /*finds the shift*/
        if(isdigit(argv[i][0])) {
            shift = atoi(argv[i]);
            if(shift > 25) {
                fprintf(stderr, "%s\n", "Over the shift limit");
                return 0;
            }
            for(j = 0; j < strlen(argv[i]); j++) {
                if(isalpha(argv[i][j])) {
                    fprintf(stderr, "%s\n", "Shift number contains a character");
                    return 0;
                }
            }
            break;
        }
        if(argv[i][0] == '-' && isdigit(argv[i][1])) {
            shift = atoi(argv[i]);
            if(shift < -25) {
                fprintf(stderr, "%s\n", "Over the shift limit");
                return 0;
            }
            for(j = 0; j < strlen(argv[i]); j++) {
                if(isalpha(argv[i][j])) {
                    fprintf(stderr, "%s\n", "Shift number contains a character");
                    return 0;
                }
            }
            break;
        }
        else{
            shift = 13;
        }

    }
    k = i;
    array = malloc(sizeof(char *) * MAX_LENGTH);
    Syad = malloc(sizeof(char) * MAX_LENGTH);
    for(i = 0; i < MAX_LENGTH; i++) {
        array[i] = malloc(sizeof(char) * MAX_LENGTH);
        strcpy(array[i], "\0");
    }
    strcpy(Syad, "\0"); /*No errors for this code ahaha*/

    /*positive shift case and no shift*/
    if(shift >= 0) {
        if(argc == 1 || (isdigit(argv[1][0]) && argc == 2)) { /*for rot13 and the specified shift*/
            i = 0;
            while(Syad[0] != '.') {
                fgets(Syad, MAX_LENGTH, stdin);
                length = strlen(Syad);
                strcpy(array[i], Syad);
                i++;
            }
            
            length = i;
            for(i = 0; i < length; i++) {
                for(j = 0; j < strlen(array[i]); j++) {
                    if(islower(array[i][j])) {
                        file = array[i][j];
                            for(k = 0; k < shift; k++) {
                                if(file == 'z') {
                                    file = 'a';
                                    file--;
                                }
                                file++;
                            }
                        array[i][j] = file;
                    }
                    if(isupper(array[i][j])) {
                        file = array[i][j];
                            for(k = 0; k < shift; k++) {
                                if(file == 'Z') {
                                    file = 'A';
                                    file--;
                                }
                                file++;
                            }
                        array[i][j] = file;
                    }
                }
            }
        }
        j = 0;
        /*when -F or F command specified with textfile*/
            if((strcmp(argv[F], "-F") == 0) || ((argv[F][0] == 'F') && (argc == 3 || 4))) {
                Sahibjeet = fopen(argv[F+1], "r");
                while(fgets(Syad, MAX_LENGTH, Sahibjeet) != NULL) {
                    length = strlen(Syad);

                    strcpy(array[j], Syad);
                    j++;
                }
                length = j;
                fclose(Sahibjeet);
                for(i = 0; i < length; i++) {
                    for(j = 0; j < strlen(array[i]); j++) {
                        if(islower(array[i][j])) {
                            file = array[i][j];
                                for(k = 0; k < shift; k++) {
                                    if(file == 'z') {
                                        file = 'a';
                                        file--;
                                    }
                                    file++;
                                }
                            array[i][j] = file;
                        }
                        if(isupper(array[i][j])) {
                            file = array[i][j];
                                for(k = 0; k < shift; k++) {
                                    if(file == 'Z') {
                                        file = 'A';
                                        file--;
                                    }
                                    file++;
                                }
                            array[i][j] = file;
                        }
                    }
                }
            }
        /*-O command in place*/
        if((strcmp(argv[O], "-O") == 0) || (argv[O][0] == 'O')) {
            dj = fopen(argv[O+1], "w");
            if((strcmp(argv[F], "-F") == 0) || (argv[F][0] == 'F')) { /*-O with -F*/
                for(j = 0; j < MAX_LENGTH; j++) {
                    fprintf(dj, "%s", array[j]);
                    if(array[j][0] == '\0') {
                        break;
                    }
                }
            }
            else {
                strcpy(Syad, "\0");
                while(Syad[0] != '.') {
                        fgets(Syad, MAX_LENGTH, stdin);
                        for(i = 0; i < strlen(Syad); i++) {
                            if(isalpha(Syad[i])) {
                                file = Syad[i];
                                for(j = 0; j < shift; j++) {
                                    if(file == 'Z') {
                                        file = 'A';
                                        file--;
                                    }
                                    if(file == 'z') {
                                        file = 'a';
                                        file--;
                                    }
                                    file++;
                                }
                                Syad[i] = file;
                            }
                        }
                        fprintf(dj, "%s", Syad);
                    }
            }
            fclose(dj);
        }
            else {/*only -F used*/
               for(i = 0; i < MAX_LENGTH; i++) {
                   printf("%s", array[i]);
                   if(array[i][0] == '.') {
                       printf("\n");
                       break;
                   }
               }
            }
    }
    /*negative shift case*/
    if(shift < 0) {
        if(isdigit(argv[1][1]) && argc == 2) {
            i = 0;
            while(Syad[0] != '.') {
                fgets(Syad, MAX_LENGTH, stdin);
                length = strlen(Syad);
                strcpy(array[i], Syad);
                i++;
            }
            length = i;
            for(i = 0; i < length; i++) {
                for(j = 0; j < strlen(array[i]); j++) {
                    if(islower(array[i][j])) {
                        file = array[i][j];
                            for(k = 0; k > shift; k--) {
                                if(file == 'a') {
                                    file = 'z';
                                    file++;
                                }
                                file--;
                            }
                        array[i][j] = file;
                    }
                    if(isupper(array[i][j])) {
                        file = array[i][j];
                            for(k = 0; k > shift; k--) {
                                if(file == 'A') {
                                    file = 'Z';
                                    file++;
                                }
                                file--;
                            }
                        array[i][j] = file;
                    }
                }
            }
        }
        j = 0;
            if((strcmp(argv[F], "-F") == 0) || ((argv[F][0] == 'F') && (argc == 3 || 4))) {
                Sahibjeet = fopen(argv[F+1], "r");
                while(fgets(Syad, MAX_LENGTH, Sahibjeet) != NULL) {
                    length = strlen(Syad);
                    strcpy(array[j], Syad);
                    j++;                
                }
                length = j;
                fclose(Sahibjeet);
                for(i = 0; i < length; i++) {
                    for(j = 0; j < strlen(array[i]); j++) {
                        if(islower(array[i][j])) {
                            file = array[i][j];
                                for(k = 0; k > shift; k--) {
                                    if(file == 'a') {
                                        file = 'z';
                                        file++;
                                    }
                                    file--;
                                }
                            array[i][j] = file;
                        }
                        if(isupper(array[i][j])) {
                            file = array[i][j];
                                for(k = 0; k > shift; k--) {
                                    if(file == 'A') {
                                        file = 'Z';
                                        file++;
                                    }
                                    file--;
                                }
                            array[i][j] = file;
                        }
                    }
                }
            }

        if((strcmp(argv[O], "-O") == 0) || (argv[O][0] == 'O')) {
            dj = fopen(argv[O+1], "w");
            if((strcmp(argv[F], "-F") == 0) || (argv[F][0] == 'F')) {
                for(j = 0; j < MAX_LENGTH; j++) {
                    fprintf(dj, "%s", array[j]);
                    if(array[j][0] == '\0') {
                        break;
                    }
                }
            }
            else {
                strcpy(Syad, "\0");
                while(Syad[0] != '.') {
                        fgets(Syad, MAX_LENGTH, stdin);
                        for(i = 0; i < strlen(Syad); i++) {
                            if(isalpha(Syad[i])) {
                                file = Syad[i];
                                for(j = 0; j > shift; j--) {
                                    if(file == 'A') {
                                        file = 'Z';
                                        file++;
                                    }
                                    if(file == 'a') {
                                        file = 'z';
                                        file++;
                                    }
                                    file--;
                                }
                                Syad[i] = file;
                            }
                        }
                        fprintf(dj, "%s", Syad);
                }
            }
            fclose(dj);
        }
            else{
               for(i = 0; i < MAX_LENGTH; i++) {
                   printf("%s", array[i]);
                   if(array[i][0] == '.') {
                       printf("\n");
                       break;
                   }
               }
            }
    }
    for(i = 0; i < MAX_LENGTH; i++) {
        free(array[i]);
    }
    free(array);
    free(Syad);

    return 0;
}